const jParser = require('jParser');
const electron = null;
const fs = require('fs');

const FILE_PATH = "./stephen.customai";


/**
* Loads a PoE zip file
*/
function readEternityFile() {
  fs.open(FILE_PATH, 'r', function(status, data) {
    if (status) {
      console.log(status.message);
      return;
    }
    var buffer = new Buffer(8);
    fs.read(data, buffer, 0, 8, 0, function(err, num) {
      var header = buffer[0] | buffer[1]<<8 | buffer[2]<<16 | buffer[3]<<24;
      var count = buffer[4] | buffer[5]<<8 | buffer[6]<<16 | buffer[7]<<24;
      console.log(header, count);
    });
  });
}

/**
* Loads a PoE zip file
*/
function readEternityFile2() {
  fs.readFile(FILE_PATH, function (err, data) {
    const parser = new jParser(data, {
      HeaderVersion: 'int32',
      Types: 'int32',
    });
    console.log(parser.parse('HeaderVersion'), parser.parse('Types'));
  });
}


readEternityFile()
readEternityFile2()